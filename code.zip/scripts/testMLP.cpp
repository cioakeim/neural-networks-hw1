#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <eigen3/Eigen/Dense>

#include "CommonLib/cifarHandlers.hpp"
#include "MLP/MultiLayerPerceptron.hpp"
#include "MLP/ActivationFunctions.hpp"
#include <time.h>
#include <csignal>

#define MAX_TRAINING 50e3
#define MAX_TEST 10e3

#define INPUT_WIDTH 32*32*3
#define OUTPUT_WIDTH 10

#define HIDDEN_WIDTH 32*32*2
#define HIDDEN_DEPTH 4

#define EPOCHS 20
#define BATCH_SIZE 50

std::ofstream file;
void handle_signal(int signal) {
  if (file.is_open()) {
      file.flush();
      file.close();
      std::cout << "File flushed and closed due to SIGINT (Ctrl+C)\n";
  }
  exit(signal);
}

int main(){
  const std::string dataset_path="../data/cifar-10-batches-bin";
  const std::string nn_path="../data/networks";
  const std::string log_filename="epoch_accuracy_log.csv";

  srand(420);

  // Loading dataset...
  Cifar10Handler c10(dataset_path); 

  std::cout<<"Loading dataset..."<<std::endl;
  std::vector<SamplePoint> training_set=c10.getTrainingList(MAX_TRAINING);
  std::vector<SamplePoint> test_set=c10.getTestList(MAX_TEST);
  std::cout<<"Loading successful..."<<std::endl;


  std::cout<<"Constructing MLP.."<<std::endl;
  std::vector<uint32_t> layer_sequence={2048,512,124};
  MultiLayerPerceptron mlp=MultiLayerPerceptron(INPUT_WIDTH,
                                                layer_sequence,
                                                OUTPUT_WIDTH);
  mlp.setName("rate_"+std::to_string(RATE)+"_reLU");
  //MultiLayerPerceptron mlp=MultiLayerPerceptron(nn_path,"testNet");
  mlp.setActivationFunction(reLU,reLUder);
  //mlp.setActivationFunction(tanh,tanhder);
  mlp.setDataset(&training_set,&test_set);
  //mlp.randomInit();
  mlp.HeRandomInit();
  std::cout<<"Construction successful.."<<std::endl;

  file.open(nn_path+"/"+log_filename,std::ios::out);
  file<<"epoch,J_train,J_test"<<std::endl;
  std::signal(SIGINT, handle_signal);

  float J_test;
  float J_train;
  float best_J_test=INFINITY;
  for(int epoch=0;epoch<EPOCHS;epoch++){
    std::cout<<"Epoch: "<<epoch<<std::endl;
    J_train=mlp.runEpoch(BATCH_SIZE);
    J_test=mlp.testModel();
    // Store results
    file<<epoch<<","<<J_train<<","<<J_test<<std::endl;
    // If result is best, store 
    if(J_test<best_J_test){
      best_J_test=J_test;
      mlp.storeToFiles(nn_path);
    }
  } 
  file.close();  // Close the file when done
  //mlp.storeToFiles(nn_path);
  return 0;
}
